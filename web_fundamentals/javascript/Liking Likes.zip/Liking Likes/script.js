var like = document.querySelector("#likes");

var likecount = 0;

function changeText() {
    likecount = likecount + 1;
    like.innerText = likecount + " Like(s)";
}
